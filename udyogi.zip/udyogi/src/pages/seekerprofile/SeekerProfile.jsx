import React from 'react'
import "./SeekerProfile.css"
const SeekerProfile = () => {
  return (
    <div>
      
    </div>
  )
}

export default SeekerProfile
